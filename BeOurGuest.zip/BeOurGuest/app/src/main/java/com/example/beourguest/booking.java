package com.example.beourguest;

public class booking {
    private String club_name;
    private String date;
    private int stags,couples,image;
    booking(String club_name, String date, int stags, int couples, int image)
    {
        this.club_name=club_name;
        this.date=date;
        this.stags=stags;
        this.couples=couples;
        this.image=image;
    }
    String getClub_name()
    {
        return club_name;
    }
    String getDate()
    {
        return date;
    }
    String getCount()
    {
        return stags+" Stags / "+couples+" Couples";
    }
    int getImage()
    {
        return image;
    }
}

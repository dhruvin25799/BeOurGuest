package com.example.beourguest;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class booking_adapter extends RecyclerView.Adapter<booking_adapter.bookingViewHolder> {

    private Context mCtx;

    private List<booking> bookingList;

    public booking_adapter(Context mCtx, List<booking> bookingList) {
        this.mCtx = mCtx;
        this.bookingList = bookingList;
    }

    @Override
    public bookingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_layout, null);
        return new bookingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(bookingViewHolder holder, int position) {

        booking booking = bookingList.get(position);

        holder.clubname.setText(booking.getClub_name());
        holder.bookingdate.setText(booking.getDate());
        holder.personcount.setText(String.valueOf(booking.getCount()));
        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(booking.getImage()));

    }


    @Override
    public int getItemCount() {
        return bookingList.size();
    }


    class bookingViewHolder extends RecyclerView.ViewHolder {

        TextView clubname, bookingdate, personcount;
        ImageView imageView;

        public bookingViewHolder(View itemView) {
            super(itemView);

            clubname = itemView.findViewById(R.id.club_name);
            bookingdate = itemView.findViewById(R.id.booking_date);
            personcount = itemView.findViewById(R.id.person_count);
            imageView = itemView.findViewById(R.id.club_photo);
        }
    }
}
